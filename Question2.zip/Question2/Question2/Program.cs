﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    /*
    50 minutes

    And now for the "real" challenge. In this program, you will determine and count the duplicate
    letters of a string. You will exclude punctuation marks (ex: .,?!:;) and numbers from the output.

    You may use basic keywords, logic and input/output functions
    (ex - if, while, for, switch, WriteLine, ReadLine, etc...)
    as well as the following built in functions and classes:

    List
    ToCharArray();
    List.Count();

    LINQ functions are NOT allowed.
    This solution must work for ANY string in the input. 

     Input: String up to 255 characters. (ex: Sea shells, sea shells, by the sea shore.)

     Output: The duplicate letters and their count in the string. 
     (ex: Sea shells sea shells by the sea shore: s:8, e:7, a:3, h:3, l:4) 

        */
    class Program
    {
        static void Main(string[] args)
        {
            //feel free to modify as pleased, this is just done for ease of use.
            string inputString;
            ConsoleKeyInfo exitProgram;

            Console.WriteLine("Please insert a string");
            inputString = Console.ReadLine();

            //Your code here...











            //Exit code
            Console.WriteLine("Press x to exit");
            exitProgram = Console.ReadKey();
            if (exitProgram.KeyChar == 'x')
            {
                Environment.Exit(0);
            }
        }
    }
}
