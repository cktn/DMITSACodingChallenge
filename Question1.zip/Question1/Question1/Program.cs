﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    /*
     Welcome coders! This 20 minute question will warm you up for what's to come. This is a pass/fail question
     worth 3 points. 
     
     Using basic programming methods, you will code a solution to reverse the characters in a string.

     You may use basic keywords, logic and input/output functions
     (ex - if, while, for, switch, WriteLine, ReadLine, etc...)
     as well as the following built in functions and classes:
     
     ToCharArray();

     This solution must work for ANY string in the input. 

      Input: String up to 255 characters. (ex: Sea shells sea shells by the sea shore)
      
      Output: The inputed string in reverse order. (ex: erohs aes eht yb sllehs aes sllehs aeS)




         */
    class Program
    {
        static void Main(string[] args)
        {
            //feel free to modify as pleased, this is just done for ease of use.
            string inputString;
            ConsoleKeyInfo exitProgram;

            Console.WriteLine("Please insert a string");
            inputString = Console.ReadLine();

            //Your code here...











            //Exit code
            Console.WriteLine("Press x to exit");
            exitProgram = Console.ReadKey();
            if(exitProgram.KeyChar == 'x')
            {
                Environment.Exit(0);
            }
        }
    }
}
